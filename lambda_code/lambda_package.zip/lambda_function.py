import boto3
import os
import io
from PIL import Image
from datetime import datetime
import uuid
import base64

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# ENVIRONMENT VARIABLES (set these in Lambda console)
OUTPUT_BUCKET = os.environ.get('OUTPUT_BUCKET')
DYNAMO_TABLE = os.environ.get('DYNAMO_TABLE')

def lambda_handler(event, context):
    try:
        # Decode image from base64 (for API Gateway payload)
        image_data = base64.b64decode(event['body'])
        image = Image.open(io.BytesIO(image_data))
        
        # Resize and grayscale
        processed_image = image.convert("L").resize((512, 512))
        
        # Prepare unique filename
        image_id = str(uuid.uuid4())
        processed_key = f"processed/{image_id}.png"
        
        # Save image to in-memory buffer
        buffer = io.BytesIO()
        processed_image.save(buffer, format="PNG")
        buffer.seek(0)
        
        # Upload to S3
        s3.put_object(
            Bucket=OUTPUT_BUCKET,
            Key=processed_key,
            Body=buffer,
            ContentType='image/png'
        )
        
        # Log metadata to DynamoDB
        table = dynamodb.Table(DYNAMO_TABLE)
        table.put_item(Item={
            'ID': image_id,
            'Filename': processed_key,
            'Timestamp': datetime.utcnow().isoformat(),
            'Status': 'processed',
            'Size': buffer.getbuffer().nbytes,
            'Format': 'PNG'
        })
        
        return {
            'statusCode': 200,
            'body': f"Image processed and stored as {processed_key}"
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': f"Error processing image: {str(e)}"
        }
